#include "fixed-point.h"
#include <stdio.h>
#include <stddef.h>
#include <stdint.h>

int main(){
  int load_avg = 3440;
  int coeff_recent_cpu_1 = mul_x_n(load_avg, 2);
  int coeff_recent_cpu_2 = add_x_n(coeff_recent_cpu_1, 1);
  int recent_cpu = 110;

  int temp_div = div_x_y(coeff_recent_cpu_1, coeff_recent_cpu_2);
  int temp_recent_cpu = convert_n_to_fixed(recent_cpu);

  int temp_mul = mul_x_y(temp_div, temp_recent_cpu);
  int temp_add = add_x_n(temp_mul, 0);
  
  int mul_100 = mul_x_n(temp_add, 100);
  int result = convert_x_to_int_near(mul_100);  

  printf("coeff_recent_cpu_1 : %d\n", coeff_recent_cpu_1);
  printf("coeff_recent_cpu_2 : %d\n", coeff_recent_cpu_2);
  printf("temp_div : %d\n", temp_div);
  printf("temp_recent_cpu : %d\n", temp_recent_cpu);
  printf("temp_mul : %d\n", temp_mul);
  printf("temp_add : %d\n", temp_add);
  printf("mul_100 : %d\n", mul_100);
  printf("result : %d\n", result);
}
